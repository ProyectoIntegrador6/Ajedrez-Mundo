<?php
$title="Mundo Ajedrez ";
/* Llamar la Cadena de Conexion*/ 
include ("config/conexion.php");
$active="active";

// Mexlike Documentation (Spanish): https://mexlike.io/como-hacer-web-scraping-con-php-simple-html-dom
// Call dependency. Download page: https://sourceforge.net/projects/simplehtmldom/files/
require 'simple_html_dom.php';

// Create DOM from URL or file
$html = file_get_html('https://www.elpais.com.uy/noticias/ajedrez');

// List of hotels
$wrap_hotels = $html->find('div.listing-row');

/**
 * @param Array $attr_image Attributes in array
 *
 * @return Image URL
 */
function get_standar_image_url($attr_image) {
  // Return default
  $url_image = 'nothing';
  // Only for style attibutes
  if (isset($attr_image['style'])) {
    // Remove background-image:url( & ) from background-image:url(URL_DE_IMAGEN)
    // You can also use regex
    $url_image = substr($attr_image['style'], 21, -2);
  }
  return $url_image;
}

// List for Hotels
$list_hotels = array();

// Find all images
foreach($wrap_hotels as $element) {
  $hotel = new stdClass();
  $hotel->name = $element->find('.listing-title', 0)->plaintext;
  $hotel->price = $element->find('.listing-epigraph', 0)->plaintext;
  $hotel->image_url = get_standar_image_url($element->find('.news-title', 0)->attr);
  $hotel->href = $element->find('.listing-image ', 0)->href;
  array_push($list_hotels, $hotel);
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title> Mundo Ajedrez </title>
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/sticky-footer-navbar.css" rel="stylesheet">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="img/favicon.png">

</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <a class="navbar-brand" href="#">Ajedrez Noticias</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault"
            aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">

                <li class="nav-item">
                    <a class="nav-link" href="index.php">Inicio</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#">Ranking</a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Referencias
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="Scraping.php">CHESS.com</a>
                            <a class="dropdown-item" href="Scraping2.php">SEMANA.com</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="Scraping3.php">TEMAS.com</a>
                        </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="index2.php">Teinda</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#">¿Quienes somos ?</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Accerder</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ml-auto" action="buscador.php" method="post">
                <input required name="PalabraClave" type="text" class="form-control mb-2" id="inlineFormInput"
                    placeholder="Busca Noticias">
                <button type="submit" class="btn btn-primary mb-2">Buscar Ahora</button>
            </form>
        </div>
    </nav>
    <main>
        <div class="container-fluid">
            <!--Section: Main carousel-->

            <div class="row">
                <div class="">
                    <!--Carousel Wrapper-->
                    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
                        <?php
							$sql_slider=mysqli_query($con,"select * from slider where estado=1 order by orden");
							$nums_slides=mysqli_num_rows($sql_slider);
						?>
                        <!--Indicators-->
                        <ol class="carousel-indicators">
                            <?php 
									for ($i=0; $i<$nums_slides; $i++){
										
										if ($i==0){
											$active="active";
										} else {
											$active="";
										}
										?>
                            <li data-target="#carousel-example-2" data-slide-to="<?php echo $i;?>"
                                class="<?php echo $active;?>"></li>
                            <?php
										
									}
								?>

                        </ol>
                        <!--/.Indicators-->
                        <!--Slides-->
                        <div class="carousel-inner" role="listbox">
                            <?php
									$active="active";
									while ($rw_slider=mysqli_fetch_array($sql_slider)){
								?>
                            <!--Second slide-->
                            <div class="carousel-item <?php echo $active;?>">
                                <!--Mask color-->
                                <div class="view hm-black-light">
                                    <img src="img/slider/<?php echo $rw_slider['url_image'];?>" class="img-fluid"
                                        alt="">
                                    <div class="full-bg-img">
                                    </div>
                                </div>
                                <!--Caption-->
                                <div class="carousel-caption">
                                    <div class="animated fadeIn">
                                        <h3 class="h3-responsive"><?php echo $rw_slider['titulo'];?></h3>
                                        <p><?php echo $rw_slider['descripcion'];?></p>
                                        <a class='btn btn-<?php echo $rw_slider['estilo_boton'];?> text-right'
                                            href="<?php echo $rw_slider['url_boton'];?>"><?php echo $rw_slider['texto_boton'];?></a>
                                        <br><br>
                                    </div>
                                </div>
                                <!--Caption-->
                            </div>
                            <?php 
								$active="";
								}
								?>
                        </div>

                        <!--/.Slides-->
                        <!--Controls-->

                        <a class="left carousel-control" href="#carousel-example-2" role="button" data-slide="prev">
                            <span class="icon-prev" aria-hidden="true"></span>
                            <span class="sr-only">Anterior</span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-2" role="button" data-slide="next">
                            <span class="icon-next" aria-hidden="true"></span>
                            <span class="sr-only">Siguiente</span>
                        </a>
                        <!--/.Controls-->
                    </div>
                    <!--/.Carousel Wrapper-->

                </div>
            </div>

            </br>
            </br>
            <div class="col-sm-12">
                    <div class="mb-5 text-center">
                        <h1 data-animate="fadeInUp" class="title">Noticias Temas</h1>
                        <p data-animate="fadeInUp" class="lead"></p>
                    </div>

            <div class="container-fluid">
                <div class="d-flex flex-wrap">
                    <?php foreach ($list_hotels as $hotel): ?>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 ">
                        <div class="wrap-box">

                            <div class="rooms-content">
                                <h4><a
                                        href="<?php echo 'https://www.elpais.com.uy/noticias/ajedrez' . $hotel->href ?>"><?php echo $hotel->name ?></a>
                                </h4>
                                <p class="price"><?php echo $hotel->price ?> / Por Noche</p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script>
    window.jQuery || document.write('<script src="assets/js/vendor/jquery-slim.min.js"><\/script>')
    </script>
    <script src="assets/js/vendor/popper.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
</body> 

</html>