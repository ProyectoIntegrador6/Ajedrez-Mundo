<?php
define("USER", "root");
define("SERVER", "localhost");
define("BD", "bd_noticias");
define("PASS", "diegoaldair");


