<?php
$title="Mundo Ajedrez ";
/* Llamar la Cadena de Conexion*/ 
include ("config/conexion.php");
$active="active";
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $title;?></title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap3.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/navbar-top-fixed.css" rel="stylesheet">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Google fonts - Roboto + Roboto Slab-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700%7CRoboto:400,700,300">
    <!-- owl carousel-->
    <link rel="stylesheet" href="vendor/owl.carousel/assets/owl.carousel.css">
    <link rel="stylesheet" href="vendor/owl.carousel/assets/owl.theme.default.css">
    <!-- animate.css-->
    <link rel="stylesheet" href="vendor/animate.css/animate.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.violet.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png">
    <!-- Tweaks for older IEs-->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

</head>

<body>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous"
        src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.3&appId=618758655299904&autoLogAppEvents=1">
    </script>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <a class="navbar-brand" href="index.php">Ajedrez Mundo</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Inicio </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#">Rankig</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Referencias
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="Scraping.php">Noticas24</a>
                            <a class="dropdown-item" href="Scraping2.php">Noticias21</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="Scraping3.php">SNoticias22</a>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="index2.php">Tienda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">¿Qienes somos ?</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Accerder</a>
                    </li>


                </ul>

                <form class="form-inline my-2 my-lg-0 ml-auto" action="buscador.php" method="post">
                    <input required name="PalabraClave" type="text" class="form-control mb-2" id="inlineFormInput"
                        placeholder="Busca Noticias">
                    <button type="submit" class="btn btn-primary mb-2">Buscar Ahora</button>
                </form>

            </div>
        </nav>
    </header>

    <main>
        <div class="container-fluid">
            <!--Section: Main carousel-->

            <div class="row">
                <div class="">
                    <!--Carousel Wrapper-->
                    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
                        <?php
							$sql_slider=mysqli_query($con,"select * from slider where estado=1 order by orden");
							$nums_slides=mysqli_num_rows($sql_slider);
						?>
                        <!--Indicators-->
                        <ol class="carousel-indicators">
                            <?php 
									for ($i=0; $i<$nums_slides; $i++){
										
										if ($i==0){
											$active="active";
										} else {
											$active="";
										}
										?>
                            <li data-target="#carousel-example-2" data-slide-to="<?php echo $i;?>"
                                class="<?php echo $active;?>"></li>
                            <?php
										
									}
								?>

                        </ol>
                        <!--/.Indicators-->
                        <!--Slides-->
                        <div class="carousel-inner" role="listbox">
                            <?php
									$active="active";
									while ($rw_slider=mysqli_fetch_array($sql_slider)){
								?>
                            <!--Second slide-->
                            <div class="carousel-item <?php echo $active;?>">
                                <!--Mask color-->
                                <div class="view hm-black-light">
                                    <img src="img/slider/<?php echo $rw_slider['url_image'];?>" class="img-fluid"
                                        alt="">
                                    <div class="full-bg-img">
                                    </div>
                                </div>
                                <!--Caption-->
                                <div class="carousel-caption">
                                    <div class="animated fadeIn">
                                        <h3 class="h3-responsive"><?php echo $rw_slider['titulo'];?></h3>
                                        <p><?php echo $rw_slider['descripcion'];?></p>
                                        <a class='btn btn-<?php echo $rw_slider['estilo_boton'];?> text-right'
                                            href="<?php echo $rw_slider['url_boton'];?>"><?php echo $rw_slider['texto_boton'];?></a>
                                        <br><br>
                                    </div>
                                </div>
                                <!--Caption-->
                            </div>
                            <?php 
								$active="";
								}
								?>
                        </div>

                        <!--/.Slides-->
                        <!--Controls-->

                        <a class="left carousel-control" href="#carousel-example-2" role="button" data-slide="prev">
                            <span class="icon-prev" aria-hidden="true"></span>
                            <span class="sr-only">Anterior</span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-2" role="button" data-slide="next">
                            <span class="icon-next" aria-hidden="true"></span>
                            <span class="sr-only">Siguiente</span>
                        </a>
                        <!--/.Controls-->
                    </div>
                    <!--/.Carousel Wrapper-->

                </div>
            </div>


            <!--
    *** REFERENCES IMAGE ***
    _________________________________________________________
    -->
            <section id="references">
                <div class="container">
                    <div class="col-sm-12">
                        <div class="mb-5 text-center">
                            <h2 data-animate="fadeInUp" class="title">Noticias Mundo Ajedrez</h2>
                            <p data-animate="fadeInUp" class="lead"></p>
                        </div>

                        <div id="detail">
                            <div class="row">
                                <div class="col-lg-10 mx-auto"><span class="close">×</span>
                                    <div id="detail-slider" class="owl-carousel owl-theme"></div>
                                    <div class="text-center">
                                        <h1 id="detail-title" class="title"></h1>
                                    </div>
                                    <div id="detail-content"></div>
                                </div>
                            </div>
                        </div>
                        <!-- Reference detail-->
                        <div id="references-masonry" data-animate="fadeInUp">
                            <div class="row">
                                <?php 
				$sql_banner_top=mysqli_query($con,"select * from noticias where estado=1 order by orden ");
				while($row=mysqli_fetch_object($sql_banner_top)){
					?>
                                <div data-category="webdesign" class="reference-item col-lg-4 col-md-6">
                                    <div class="reference"><a href="#"><img
                                                src="img/banner/<?php echo $row->url_image;?>" alt="" class="img-fluid">
                                            <div class="overlay">
                                                <div class="inner">
                                                    <h3 class="h4 reference-title"><?php echo $row->titulo;?></h3>
                                                    <p><?php echo $row->descripcion_corta;?></p>
                                                </div>
                                            </div>
                                        </a>
                                        <div data-images="img/banner/<?php echo $row->url_image;?>"
                                            class="sr-only reference-description">
                                            <p><?php echo $row->descripcion;?></p>

                                            <p class="buttons text-center"><a href="<?php echo $row->url_web;?>"
                                                    class="btn btn-outline-primary"><i class="fa fa-globe"></i> Visitas
                                                    Sitio Web</a></p>

                                            <div class="fb-comments"
                                                data-href="https://developers.facebook.com/docs/plugins/comments#configurator"
                                                data-width="720" data-numposts="20"></div>
                                        </div>
                                    </div>
                                </div>
                                <?php
				}
			?>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    </main>
    <!--/Main layout-->
    <!--Footer-->
    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-lg-left">
                    <p class="social"><a href=" " class="external facebook wow fadeInUp"><i
                                class="fa fa-facebook"></i></a><a href="#" data-wow-delay="0.2s"
                            class="external instagram wow fadeInUp"><i class="fa fa-instagram"></i></a><a href="#"
                            data-wow-delay="0.4s" class="external gplus wow fadeInUp"><i
                                class="fa fa-google-plus"></i></a><a href="#" data-wow-delay="0.6s"
                            class="email wow fadeInUp"><i class="fa fa-envelope"></i></a></p>
                </div>
                <!-- /.6-->
                <div class="col-md-6 text-center text-lg-right mt-4 mt-lg-0">
                    <p>© <?php echo date('Y');?> Diego Aldair Tello.</p>
                </div>
                <div class="col-12 mt-4">
                    <p class="template-bootstrapious"> <a href="https://www.bootstrapious.com">Ajedrez Mundo</a>
                        <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!--/.Footer-->
    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

    <script>
    window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')
    </script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <!-- Tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="vendor/waypoints/lib/jquery.waypoints.min.js"></script>
    <script src="vendor/jquery.counterup/jquery.counterup.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu5nZKbeK-WHQ70oqOWo-_4VmwOwKP9YQ"></script>
    <script src="js/front.js"></script>
    <script src="js/popper.min.js"></script>

</body>

</html>