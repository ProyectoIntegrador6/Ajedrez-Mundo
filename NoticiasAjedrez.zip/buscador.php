<?php include "config/conexion.php";?>

<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title> Mundo Ajedrez </title>
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/sticky-footer-navbar.css" rel="stylesheet">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
    <link rel="shortcut icon" href="img/favicon.png">


</head>

<body>

    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <a class="navbar-brand" href="#">Ajedrez Mundo</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav mr-auto">

                    <li class="nav-item ">
                        <a class="nav-link" href="index.php">Inicio </span></a>

                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="">Rankig</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Referencias
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="Scraping.php">CHESS.com</a>
                        <a class="dropdown-item" href="Scraping2.php">SEMANA.com</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="Scraping3.php">TEMAS.com</a>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="index2.php">Tienda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">¿Qienes somos ?</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Accerder</a>
                    </li>

                </ul>
                <form method="post">
                    <div class="form-row align-items-center">
                        <div class="col-auto">
                            <label class="sr-only" for="inlineFormInput">Buscar Noticia</label>
                            <input required name="PalabraClave" type="text" class="form-control mb-2"
                                id="inlineFormInput" placeholder="Buscar Noticias ">
                            <input name="buscar" type="hidden" class="form-control mb-2" id="inlineFormInput" value="v">
                        </div>

                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary mb-2">Buscar Ahora</button>
                        </div>
                    </div>
                </form>
            </div>
        </nav>
    </header>

    <div class="container-fluid">
        <!--Section: Main carousel-->

        <div class="row">
            <div class="">
                <!--Carousel Wrapper-->
                <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
                    <?php
							$sql_slider=mysqli_query($con,"select * from slider where estado=1 order by orden");
							$nums_slides=mysqli_num_rows($sql_slider);
						?>
                    <!--Indicators-->
                    <ol class="carousel-indicators">
                        <?php 
									for ($i=0; $i<$nums_slides; $i++){
										
										if ($i==0){
											$active="active";
										} else {
											$active="";
										}
										?>
                        <li data-target="#carousel-example-2" data-slide-to="<?php echo $i;?>"
                            class="<?php echo $active;?>"></li>
                        <?php
										
									}
								?>

                    </ol>
                    <!--/.Indicators-->
                    <!--Slides-->
                    <div class="carousel-inner" role="listbox">
                        <?php
									$active="active";
									while ($rw_slider=mysqli_fetch_array($sql_slider)){
								?>
                        <!--Second slide-->
                        <div class="carousel-item <?php echo $active;?>">
                            <!--Mask color-->
                            <div class="view hm-black-light">
                                <img src="img/slider/<?php echo $rw_slider['url_image'];?>" class="img-fluid" alt="">
                                <div class="full-bg-img">
                                </div>
                            </div>
                            <!--Caption-->
                            <div class="carousel-caption">
                                <div class="animated fadeIn">
                                    <h3 class="h3-responsive"><?php echo $rw_slider['titulo'];?></h3>
                                    <p><?php echo $rw_slider['descripcion'];?></p>
                                    <a class='btn btn-<?php echo $rw_slider['estilo_boton'];?> text-right'
                                        href="<?php echo $rw_slider['url_boton'];?>"><?php echo $rw_slider['texto_boton'];?></a>
                                    <br><br>
                                </div>
                            </div>
                            <!--Caption-->
                        </div>
                        <?php 
								$active="";
								}
								?>
                    </div>

                    <!--/.Slides-->
                    <!--Controls-->

                    <a class="left carousel-control" href="#carousel-example-2" role="button" data-slide="prev">
                        <span class="icon-prev" aria-hidden="true"></span>
                        <span class="sr-only">Anterior</span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-2" role="button" data-slide="next">
                        <span class="icon-next" aria-hidden="true"></span>
                        <span class="sr-only">Siguiente</span>
                    </a>
                    <!--/.Controls-->
                </div>
                <!--/.Carousel Wrapper-->

            </div>
        </div>

        </br>
        </br>
        <!-- Begin page content -->

        <div class="container">
            <h2 data-animate="fadeInUp" class="title"> Buscar Noticias</h2>
            <hr>

            <div class="row">
                <div class="col-12 col-md-12">
                    <!-- Contenido -->



                    <?php
 
if(!empty($_POST))
{
      $aKeyword = explode(" ", $_POST['PalabraClave']);
      $query ="SELECT * FROM noticias WHERE titulo like '%" . $aKeyword[0] . "%' OR descripcion_corta like '%" . $aKeyword[0] . "%'";
      
     for($i = 1; $i < count($aKeyword); $i++) {
        if(!empty($aKeyword[$i])) {
            $query .= " OR descripcion_corta like '%" . $aKeyword[$i] . "%'";
        }
      }
     
     $result = $con->query($query);
     echo "<br>Has buscado la palabra clave:<b> ". $_POST['PalabraClave']."</b>";
                     
     if(mysqli_num_rows($result) > 0) {
        $row_count=0;
        echo "<br><br>Resultados encontrados: ";
        echo "<br><table class='table table-striped'>";
        While($row = $result->fetch_assoc()) {   
            $row_count++;                         
            echo "<tr><td>".$row_count." </td><td>". $row['titulo'] . "</td><td>". $row['descripcion_corta'] . "</td></tr>";
        }
        echo "</table>";
	
    }
    else {
        echo "<br>Resultados encontrados: Ninguno";
		
    }
}
 
?>




                    <!-- Fin Contenido -->
                </div>
            </div><!-- Fin row -->
        </div><!-- Fin container -->
        <footer class="footer">

        </footer>
        <!-- Bootstrap core JavaScript
    ================================================== -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
        </script>
        <script>
        window.jQuery || document.write('<script src="assets/js/vendor/jquery-slim.min.js"><\/script>')
        </script>
        <script src="assets/js/vendor/popper.min.js"></script>
        <script src="dist/js/bootstrap.min.js"></script>
</body>

</html>